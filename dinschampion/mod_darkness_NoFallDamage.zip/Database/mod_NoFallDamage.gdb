ModNoFallDamage overrides GameSystem
{
	FallingDamageMinSpeed	-999999
	FallingDamageMinDamage	0
	FallingDamageMaxDamage	0
}
