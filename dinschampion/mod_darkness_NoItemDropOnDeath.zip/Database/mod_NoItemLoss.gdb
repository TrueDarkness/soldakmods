ModNoItemLoss overrides GameSystem
{
	DropItemsInBagsOnDeath		0
}
