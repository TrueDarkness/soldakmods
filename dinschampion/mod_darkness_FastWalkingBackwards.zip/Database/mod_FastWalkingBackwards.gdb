ModFastWalkingBackwards overrides GameSystem
{
	RunningBackwardsMult		1
}
