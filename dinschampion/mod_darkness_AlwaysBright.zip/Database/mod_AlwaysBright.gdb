ModAlwaysBright overrides LightingSystem
{
	linearFalloff		0
	AdjacentIntensityOpenReduction		0
	DiagonalIntensityOpenReduction		0
	AdjacentIntensityPartialReduction	0
	DiagonalIntensityPartialReduction	0
	AdjacentIntensityClosedReduction	0
	DiagonalIntensityClosedReduction	0
}
