ModFreeQuestTargetSearch overrides GameSystem
{
	SearchForItemPriceBase		0
	SearchForItemPricePerLevel	0
	SearchForEnemyPriceBase		0
	SearchForEnemyPricePerLevel	0
}
