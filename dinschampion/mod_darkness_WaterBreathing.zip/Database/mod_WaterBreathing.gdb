ModWaterBreathing overrides GameSystem
{
	FullOxygenTime			9999999.0
	OxygenDamageTime		0.0
	OxygenDamagePercent		0.0
	OxygenRegainMult		9999999.0
}
