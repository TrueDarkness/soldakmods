modFreeRespec overrides GameSystem
{
	ValueEachPointTraining		0.0
	ValueEachPointUntraining	0.0
}
