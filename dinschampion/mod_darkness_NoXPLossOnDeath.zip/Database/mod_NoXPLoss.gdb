ModNoXPLoss overrides GameSystem
{
	XpDebtPerDeath		0.0
	SoulStoneXpReduction	1
}
